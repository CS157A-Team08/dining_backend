
const express = require('express')
const bodyParser = require('body-parser')
const { restaurant} = require('./sequelize')
const app = express()
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
    extended: true
  }));


// Create a restaurant
app.post('/rest', (req, res) => {

      restaurant.create(req.body)
        .then(user => res.json(user))
})
    
        
      
    
 

// create an employee
app.post('/emp', (req, res) => {`=`
console.log("employee", req.body)
Employee.create(req.body)
.then(employee => res.json(employee))
})
// get all restaurant
app.get('/allrest', (req, res) => {
restaurant.findAll().then(restaurant =>
res.json(restaurant))
})

// get all authors
app.get('/allemp', (req, res) => {
Employee.findAll().then(employees =>
res.json(employees))
})

// get book by  bookId
app.get('/rest/:id', (req, res) => {
restaurant.findOne(
{
where: { id: req.params.storeID, },
}
).then(restaurant => res.json(restaurant))
})

// get author by id
app.get('/emp/:id', (req, res) => {
employee.findOne(
{
where: { id: req.params.employeeID, },
}
).then(employee => res.json(employee))
})

const port = 12000
app.listen(port, () => {console.log(`Running on http://localhost:${port}`)
})